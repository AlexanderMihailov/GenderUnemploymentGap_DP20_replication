

************************************************************************************
* README_GenderUnemplGapEA11_DP20.txt                                              *
*                                                                                  *
*     Replication archive with the data and programs for                           *
*                                                                                  *
*     Mihailov, Razzu and Wang (Econ Dept Uni Reading DP 2020-26: December 2020),  *
*     "The Gender Unemployment Gap Across the Euro Area: The Role                  * 
*     of Macroeconomic Shocks and Labour Market Institutions"                      *
*     https://ideas.repec.org/p/rdg/emxxdp/em-dp2020-26.html                       *
*                                                                                  *
* First created: 18 November 2019 by Zhe Wang                                      *
* Last modified: 2 January 2021 by Alexander Mihailov                              *
************************************************************************************


This GenderUnemplGapEA11_DP20_replication.zip archive contains the data and code to
replicate the results reported in Mihailov, Razzu and Wang (2020: Discussion Paper).
The archive is structured into two folders and also has two Excel files, as follows.

************************************************************************************ 

The two Excel files contain data and are called as input in the programs,
as explained next.

The "data and figures.xlsx" file contains the panel data for all dependent
variables (unemployment rates by gender, age, marital status, and educational
attainment level) and the shocks. For details on the data construction and sources,
see Appendix A in the paper. This file is used as input for creating Figures 1 and 2 
and Tables C1, C2, and C3 in the paper.

The "correlation of LMIs.xlsx" file contains the data for labour market
institutions. For details on the data construction and sources, see again Appendix A.
The file is used for calculating the pairwise correlations across labour market
institutions, that is, Table B8 in the paper.

The two folders within this zip archive are:

"estimation" - contains data (in *.xlsx and *.dta files) and code (in *.do files)
"estimation results" - contains estimation results (in *.csv and *.xlsx files)

************************************************************************************

The programs were executed using STATA version 14 for PC. The code consists of three parts.  
_______

Part 1: Benchmark Estimation

To generate the benchmark results in Table 1, use the "Data_EA11_2000_2013_Eurostat.dta" 
file and run the "Table_1_Benchmark.do" file (in the "estimation" folder, containing also
all other data and code, as mentioned). The output is saved in the "Table_1_Benchmark.csv"
file (see the "estimation results" folder, containing also all other results, as mentioned).
_______

Part 2: Analysis by Demographic Composition

To generate the regression results for unemployment rates by gender and age in Table 2, use
the "Data_EA11_2000_2013_Eurostat.dta" file and run the "Table_2_Age_composition.do" file.
The output is saved in the "Table_2_Age_composition.csv" file.
 
To generate the regression results for unemployment rates by gender and marital status in Table 3,
use the "Data_EA11_2000_2013_Eurostat.dta" file and run the "Table_3_MaritalStatus_composition.do"
file. The output is saved in the "Table_3_MaritalStatus_composition.csv" file.

To generate the regression results for unemployment rates by gender and education in Table 4,
use the "Data_EA11_2000_2013_Eurostat.dta" file and run the "Table_4_Education_composition.do"
file. The output is saved in the "Table_4_Education_composition.csv" file.
_______

Part 3: Robustness Check for the Benchmark Results

To check the cross-section stability of the benchmark results, use the "Data_EA11_2000_2013_Eurostat.dta"
file and run the "Table_B1_B2_B3_Robustness_crosssection_stability.do" file. Notice that commenting out
"gen idshock= ..." one by one needs to be executed for dropping a country. The output is saved in the
"Table_B1_B2_B3_Robustness_crosssection_stability.csv" file.

To check the period stability of the benchmark results, use the "Data_EA11_2000_2013_Eurostat.dta"
file and run the "Table_B4_Robustness_period_stability.do" file. Notice that commenting out
"gen idshock= ..." one by one needs to be executed for dropping one year. The output is saved in the
"Table_B4_Robustness_period_stability.csv" file.

To test for endogeneity by using lagged shocks, use the "Data_for shock endogeneity_lag_EA11_2000_2013.dta"
file and run the "Table_B5_B6_B7_Robustness_endogeneity.do" file. The output is saved in the 
"Table_B5_Robustness_endogeneity_lagged_shocks.csv" file.

To test for endogeneity by using lagged institutions, use the "Data_for LMIs endogeneity_lag_EA11_2000_2013.dta" 
file and run the "Table_B5_B6_B7_Robustness_endogeneity.do" file. The output is saved in the 
"Table_B6_Robustness_endogeneity_lagged_LMIs.csv" file.

To test for endogeneity by restricting variations in institutions, firstly, use the 
"Data_for LMIs endogeneity_3year_EA11_2000_2013.dta" file and run the "Table_B5_B6_B7_Robustness_endogeneity.do"
file; secondly, use the "Data_for LMIs endogeneity_fix2000_EA11_2000_2013.dta" file and run the
"Table_B5_B6_B7_Robustness_endogeneity.do" file again. The output is saved in the
"Table_B7_Robustness_endogeneity_restriction_LMIs.csv" file.

To test for multicollinearity, use the "Data_EA11_2000_2013_Eurostat.dta" file and run the
"Table_B9_Robustness_multicollinearity.do" file. The output is saved in the
"Table_B9_Robustness_multicollinearity.xlsx" file.

************************************************************************************